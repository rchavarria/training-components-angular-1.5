(function() {
    "use strict";

    angular.module("psMovies", []);

}());